import React from 'react'

const Reducer = () => {
  return (
    <div>Reducer</div>
  )
}

export  {Reducer}